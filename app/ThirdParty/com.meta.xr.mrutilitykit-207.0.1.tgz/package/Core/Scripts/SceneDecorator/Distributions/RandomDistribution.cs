/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * Licensed under the Oculus SDK License Agreement (the "License");
 * you may not use the Oculus SDK except in compliance with the License,
 * which is provided at the time of installation or download, or which
 * otherwise accompanies this software in either electronic or hard copy form.
 *
 * You may obtain a copy of the License at
 *
 * https://developer.oculus.com/licenses/oculussdk/
 *
 * Unless required by applicable law or agreed to in writing, the Oculus SDK
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System;
using Meta.XR.Util;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Meta.XR.MRUtilityKit.SceneDecorator
{
    /// <summary>
    /// A distribution that randomly places objects defined by the scenedecorator
    /// </summary>
    [Serializable]
    [Feature(Feature.Scene)]
    [Obsolete("SceneDecorator is deprecated and will be removed in a future version.")]
    public class RandomDistribution : SceneDecorator.IDistribution
    {
        [SerializeField]
        [Tooltip("How many entries to generate per unit (1m)")]
        private float numPerUnit = 10f;

        /// <summary>
        /// Distributes randomly decorations.
        /// </summary>
        /// <param name="sceneDecorator">The scene decorator used to generate the decoration.</param>
        /// <param name="sceneAnchor">The MRUKAnchor that defines the surface on which to distribute the decoration.</param>
        /// <param name="sceneDecoration">The scene decoration to be distributed.</param>
        public void Distribute(SceneDecorator sceneDecorator, MRUKAnchor sceneAnchor, SceneDecoration sceneDecoration)
        {
            Vector3 anchorScale = Vector3.one;

            if (sceneAnchor.PlaneRect.HasValue)
            {
                anchorScale = new(sceneAnchor.PlaneRect.Value.width, sceneAnchor.PlaneRect.Value.height, 1);
            }
            else if (sceneAnchor.VolumeBounds.HasValue)
            {
                anchorScale = sceneAnchor.VolumeBounds.Value.size;
            }

            var numToGenerate = Mathf.Max((int)Mathf.Ceil(anchorScale.x * anchorScale.y * numPerUnit), 1);
            for (; numToGenerate > 0; --numToGenerate)
            {
                var rndX = Random.value;
                var rndY = Random.value;

                sceneDecorator.GenerateOn(new Vector2(rndX * anchorScale.x - anchorScale.x / 2, rndY * anchorScale.y - anchorScale.y / 2),
                    new Vector2(rndX, rndY),
                    sceneAnchor,
                    sceneDecoration);
            }
        }
    }
}
